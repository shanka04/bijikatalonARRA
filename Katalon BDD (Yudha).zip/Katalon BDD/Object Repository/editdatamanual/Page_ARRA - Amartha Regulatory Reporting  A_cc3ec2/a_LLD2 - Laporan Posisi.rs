<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_LLD2 - Laporan Posisi</name>
   <tag></tag>
   <elementGuidId>3f16a8c3-fde9-4691-98bf-d4b2e058fcf3</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//ul[@id='rc-menu-uuid-83330-1-10_2-popup']/li[2]/span/a</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>li.ant-menu-item.ant-menu-item-active.ant-menu-item-only-child > span.ant-menu-title-content > a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;LLD2 - Laporan Posisi&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>d5df4f9a-1230-4ef2-bbff-75cce2e64e5b</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>/form/F_LLD2</value>
      <webElementGuid>6c96e883-9921-4ab5-b721-ea5794c3346d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>LLD2 - Laporan Posisi</value>
      <webElementGuid>b42fd925-b520-4a8e-952b-cc612755c89a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;rc-menu-uuid-83330-1-10_2-popup&quot;)/li[@class=&quot;ant-menu-item ant-menu-item-active ant-menu-item-only-child&quot;]/span[@class=&quot;ant-menu-title-content&quot;]/a[1]</value>
      <webElementGuid>d593b096-bf5c-438a-9130-1495bccfc7b7</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//ul[@id='rc-menu-uuid-83330-1-10_2-popup']/li[2]/span/a</value>
      <webElementGuid>5a55570e-aef8-4aed-815c-db07dd9a77d0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='LLD1 - Laporan Transaksi'])[1]/following::a[1]</value>
      <webElementGuid>78368d6f-ef98-4aa5-a71d-47b3a288c797</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Report Bank'])[1]/following::a[2]</value>
      <webElementGuid>c1f496ac-19f1-469a-bdc0-dc8b5ab5f6c0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='RKD1 - Laporan Transaksi Reksus'])[1]/preceding::a[1]</value>
      <webElementGuid>b1b81be0-90e0-465e-9454-0462dbfd3266</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, '/form/F_LLD2')]</value>
      <webElementGuid>9f82a882-b8bc-47dd-8b5d-d1b0ea8d65f1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li[2]/span/a</value>
      <webElementGuid>905fd06d-b3f0-43ff-9478-856f7707eabd</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '/form/F_LLD2' and (text() = 'LLD2 - Laporan Posisi' or . = 'LLD2 - Laporan Posisi')]</value>
      <webElementGuid>3fb533c8-12d7-4945-a8d8-e652213e57b0</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
