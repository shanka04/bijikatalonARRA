<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_LLD2 - Laporan Posisi</name>
   <tag></tag>
   <elementGuidId>c0260d60-5946-4321-a0ac-eca5278ac87d</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//ul[@id='rc-menu-uuid-18296-1-10_2-popup']/li[2]/span/a</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>li.ant-menu-item.ant-menu-item-active.ant-menu-item-only-child > span.ant-menu-title-content > a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;LLD2 - Laporan Posisi&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>688845e4-6b8b-4114-ad4a-1a8fde07d157</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>/form/F_LLD2</value>
      <webElementGuid>e053bfe1-813f-4e5b-bb97-e8ccbd2fa6d3</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>LLD2 - Laporan Posisi</value>
      <webElementGuid>1fd27d33-0bc9-4218-bd43-79b4dacc6d2f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;rc-menu-uuid-18296-1-10_2-popup&quot;)/li[@class=&quot;ant-menu-item ant-menu-item-active ant-menu-item-only-child&quot;]/span[@class=&quot;ant-menu-title-content&quot;]/a[1]</value>
      <webElementGuid>7168324b-bfbe-463b-aa6c-1f833ccb15ed</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//ul[@id='rc-menu-uuid-18296-1-10_2-popup']/li[2]/span/a</value>
      <webElementGuid>1967b4fb-cfba-4b99-b947-bff037a041f9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='LLD1 - Laporan Transaksi'])[1]/following::a[1]</value>
      <webElementGuid>cef65b44-3dc2-40c3-bb17-27886113f0bb</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Report Bank'])[1]/following::a[2]</value>
      <webElementGuid>411d8172-73d2-4662-ba1b-a7f96bdf9d73</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='RKD1 - Laporan Transaksi Reksus'])[1]/preceding::a[1]</value>
      <webElementGuid>b1d1b0a9-df34-4f36-9f15-b8a11b535220</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, '/form/F_LLD2')]</value>
      <webElementGuid>6dcb8721-1ebe-48c8-bde8-3d8152104776</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li[2]/span/a</value>
      <webElementGuid>68490e9c-a0cf-4576-8d20-c969f8a085b9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '/form/F_LLD2' and (text() = 'LLD2 - Laporan Posisi' or . = 'LLD2 - Laporan Posisi')]</value>
      <webElementGuid>6aeababe-9738-4f83-ae7b-f04a0254e169</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
