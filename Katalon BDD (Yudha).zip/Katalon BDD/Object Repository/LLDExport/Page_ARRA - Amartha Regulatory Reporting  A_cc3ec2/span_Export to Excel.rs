<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_Export to Excel</name>
   <tag></tag>
   <elementGuidId>25260f14-3ab8-441d-a13c-fd1506c899e3</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[(text() = 'Export to Excel' or . = 'Export to Excel')]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>#82f7ae95-ab65-45ae-929f-1acb32d229eb_0 > li.k-item.k-menu-item.k-first > span.k-link.k-menu-link > span.k-menu-link-text</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//ul[@id='82f7ae95-ab65-45ae-929f-1acb32d229eb_0']/li/span/span[2]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:text=&quot;Export to Excel&quot;i</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>e26a3d83-1c57-4d48-89be-282c3c0f5606</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>k-menu-link-text</value>
      <webElementGuid>4fe582d1-bda0-47c8-8963-0ea4ce91fc1b</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Export to Excel</value>
      <webElementGuid>6f2fd2cb-f8ee-463b-9346-1944c36783fb</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;82f7ae95-ab65-45ae-929f-1acb32d229eb_0&quot;)/li[@class=&quot;k-item k-menu-item k-first&quot;]/span[@class=&quot;k-link k-menu-link&quot;]/span[@class=&quot;k-menu-link-text&quot;]</value>
      <webElementGuid>380637d5-df0d-40a9-8f63-51e6d1997189</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//ul[@id='82f7ae95-ab65-45ae-929f-1acb32d229eb_0']/li/span/span[2]</value>
      <webElementGuid>a48e9ca7-d3a8-4d75-bcb6-5ec5f480a52e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Amartha Regulatory Reporting &amp; Analytics (ARRA)'])[1]/following::span[3]</value>
      <webElementGuid>9cbc30a2-8ade-4956-aa0c-a64a687f2b13</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='+'])[3]/following::span[9]</value>
      <webElementGuid>0c51d5be-e007-4f88-9ee1-f1a74724d18a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Export to CSV'])[1]/preceding::span[2]</value>
      <webElementGuid>e4495ef1-679d-4636-9d82-d1186337dcca</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Export to Delimited TF'])[1]/preceding::span[5]</value>
      <webElementGuid>151812a1-8af6-4041-9442-c36f508ad006</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Export to Excel']/parent::*</value>
      <webElementGuid>8e54ba49-470e-4874-9184-bd6f58a5200c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/div/ul/li/span/span[2]</value>
      <webElementGuid>ffc37fe1-a2d4-469e-acf9-512999e44e87</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = 'Export to Excel' or . = 'Export to Excel')]</value>
      <webElementGuid>da197456-2538-4993-8760-15f3587aa5b4</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
