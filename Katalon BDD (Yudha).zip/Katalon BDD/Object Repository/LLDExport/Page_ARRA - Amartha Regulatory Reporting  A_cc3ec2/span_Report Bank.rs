<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_Report Bank</name>
   <tag></tag>
   <elementGuidId>aac1b20f-05cc-4f77-96ee-c9fbeb8a081b</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//ul[@id='rc-menu-uuid-18296-1-10-popup']/li[2]/div/span/div/span</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>span[title=&quot;Report Bank&quot;]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:text=&quot;Report Bank&quot;i</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>01133f91-017a-4ea3-adb0-4e06bfbb99a6</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>title</name>
      <type>Main</type>
      <value>Report Bank</value>
      <webElementGuid>74b83763-71ac-4e5b-bb7a-aa9f6a27883e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Report Bank</value>
      <webElementGuid>ca9d8fea-dc11-4157-824c-3581b16c7f03</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;rc-menu-uuid-18296-1-10-popup&quot;)/li[@class=&quot;ant-menu-submenu ant-menu-submenu-inline ant-menu-submenu-active&quot;]/div[@class=&quot;ant-menu-submenu-title&quot;]/span[@class=&quot;ant-menu-title-content&quot;]/div[1]/span[1]</value>
      <webElementGuid>12e6263e-e783-454d-acdd-3e69577f1418</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//ul[@id='rc-menu-uuid-18296-1-10-popup']/li[2]/div/span/div/span</value>
      <webElementGuid>75f3bc7b-8759-46ff-b7ae-3873a3f49ebe</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Master'])[1]/following::span[2]</value>
      <webElementGuid>98fd4598-dafd-44cd-a3df-36acb7f717f0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='LLD'])[1]/following::span[4]</value>
      <webElementGuid>72c2500e-a31c-4c1a-9211-98d187c567ae</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Report Non Bank'])[1]/preceding::span[1]</value>
      <webElementGuid>5d192dc5-dca2-4540-a9ba-b0273d8c751e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Internal Validation'])[1]/preceding::span[3]</value>
      <webElementGuid>10bffe79-af34-4451-a00f-cfa5b7649991</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Report Bank']/parent::*</value>
      <webElementGuid>0123fb89-10f6-47a1-8d45-b9928b0cc0ac</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li[10]/ul/li[2]/div/span/div/span</value>
      <webElementGuid>2bd93da1-8ee5-4f11-862c-f28dc6c52ff8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[@title = 'Report Bank' and (text() = 'Report Bank' or . = 'Report Bank')]</value>
      <webElementGuid>84f87677-58c5-429b-a92c-9317a28bdbd5</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
