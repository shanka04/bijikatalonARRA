<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_Report Bank</name>
   <tag></tag>
   <elementGuidId>fa5610cd-93eb-4f3c-9a4a-dfd01beeb759</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//ul[@id='rc-menu-uuid-47159-1-10-popup']/li[2]/div/span/div/span</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>span[title=&quot;Report Bank&quot;]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:text=&quot;Report Bank&quot;i</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>8823a4a0-2ff8-46ab-b3e2-f99b80dc888f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>title</name>
      <type>Main</type>
      <value>Report Bank</value>
      <webElementGuid>820185f6-b216-4300-b4d3-fdd7a2161fbd</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Report Bank</value>
      <webElementGuid>cfd76eb6-b1cd-4b94-9a45-279ce02ebecb</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;rc-menu-uuid-47159-1-10-popup&quot;)/li[@class=&quot;ant-menu-submenu ant-menu-submenu-inline ant-menu-submenu-active&quot;]/div[@class=&quot;ant-menu-submenu-title&quot;]/span[@class=&quot;ant-menu-title-content&quot;]/div[1]/span[1]</value>
      <webElementGuid>1628dcc3-5ef9-4121-a93d-e3878b4aaa31</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//ul[@id='rc-menu-uuid-47159-1-10-popup']/li[2]/div/span/div/span</value>
      <webElementGuid>c3b8873a-9da3-4d85-80b6-49592e58f0a0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Master'])[1]/following::span[2]</value>
      <webElementGuid>0d3ef1ae-2662-4b01-8c6e-7ebb093f17e7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='LLD'])[1]/following::span[4]</value>
      <webElementGuid>f86591af-4733-41d9-be98-c6c43fb4f295</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Report Non Bank'])[1]/preceding::span[1]</value>
      <webElementGuid>236b6ae9-a736-4cc0-9d57-add9a86d296c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Internal Validation'])[1]/preceding::span[3]</value>
      <webElementGuid>0fb86ef0-a483-421c-ae95-66238a795ef7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Report Bank']/parent::*</value>
      <webElementGuid>6ba383ba-eb2d-43b1-b3c9-7a8750c0f2a0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li[10]/ul/li[2]/div/span/div/span</value>
      <webElementGuid>910f9edc-bb49-481e-a054-211deb6f5fb7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[@title = 'Report Bank' and (text() = 'Report Bank' or . = 'Report Bank')]</value>
      <webElementGuid>9403b435-e536-429d-840a-8abf1e3355ce</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
