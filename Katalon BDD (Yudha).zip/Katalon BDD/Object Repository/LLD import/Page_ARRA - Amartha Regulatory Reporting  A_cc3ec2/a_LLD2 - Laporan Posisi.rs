<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_LLD2 - Laporan Posisi</name>
   <tag></tag>
   <elementGuidId>46520a01-6040-4cb7-8aef-6827773b6bef</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//ul[@id='rc-menu-uuid-47159-1-10_2-popup']/li[2]/span/a</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>li.ant-menu-item.ant-menu-item-active.ant-menu-item-only-child > span.ant-menu-title-content > a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;LLD2 - Laporan Posisi&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>f31f137a-8da7-43ee-9457-4542cdc42558</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>/form/F_LLD2</value>
      <webElementGuid>c684f97a-0fec-46e5-921b-9a0e050724d7</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>LLD2 - Laporan Posisi</value>
      <webElementGuid>7aaca619-6e00-410d-80de-69fda63b39f7</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;rc-menu-uuid-47159-1-10_2-popup&quot;)/li[@class=&quot;ant-menu-item ant-menu-item-active ant-menu-item-only-child&quot;]/span[@class=&quot;ant-menu-title-content&quot;]/a[1]</value>
      <webElementGuid>02c92bea-21a3-4b5d-9149-0a5720c48383</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//ul[@id='rc-menu-uuid-47159-1-10_2-popup']/li[2]/span/a</value>
      <webElementGuid>fef1cf0a-fb91-4419-bd59-96c867ffd560</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='LLD1 - Laporan Transaksi'])[1]/following::a[1]</value>
      <webElementGuid>51619c73-17a7-4268-bfd9-514a724daf46</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Report Bank'])[1]/following::a[2]</value>
      <webElementGuid>5012622a-384a-46b3-8b18-f381a694f538</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='RKD1 - Laporan Transaksi Reksus'])[1]/preceding::a[1]</value>
      <webElementGuid>43e22d9e-2a56-4939-9565-b1155b942e85</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, '/form/F_LLD2')]</value>
      <webElementGuid>08195a6d-61c6-4383-888a-68e256fdd47a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li[2]/span/a</value>
      <webElementGuid>c4afe98b-67ca-4fab-848b-9e6c2d787dd3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '/form/F_LLD2' and (text() = 'LLD2 - Laporan Posisi' or . = 'LLD2 - Laporan Posisi')]</value>
      <webElementGuid>ff5ba46e-3d7b-4af9-ac50-e134a5673f79</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
