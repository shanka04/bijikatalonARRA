<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_Report Bank</name>
   <tag></tag>
   <elementGuidId>a6be2ba6-ac6b-4185-84b9-0dcdbb021e6c</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>span[title=&quot;Report Bank&quot;]</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//ul[@id='rc-menu-uuid-22930-1-10-popup']/li[2]/div/span/div/span</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:text=&quot;Report Bank&quot;i</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>96b3ffc5-4a93-4354-8e7b-a2fbe978fa57</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>title</name>
      <type>Main</type>
      <value>Report Bank</value>
      <webElementGuid>d21f0cec-2cc1-47cd-a8ef-40bc1d92cbbd</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Report Bank</value>
      <webElementGuid>be544732-43e4-4d8c-a82e-300edf8d8432</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;rc-menu-uuid-22930-1-10-popup&quot;)/li[@class=&quot;ant-menu-submenu ant-menu-submenu-inline ant-menu-submenu-active&quot;]/div[@class=&quot;ant-menu-submenu-title&quot;]/span[@class=&quot;ant-menu-title-content&quot;]/div[1]/span[1]</value>
      <webElementGuid>424183b6-e186-4ca9-92e4-e9461bb54b87</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//ul[@id='rc-menu-uuid-22930-1-10-popup']/li[2]/div/span/div/span</value>
      <webElementGuid>cd14c52d-ff7c-4842-a69e-7c5c09a7d9ee</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Master'])[1]/following::span[2]</value>
      <webElementGuid>8d28e536-e8e1-4c16-bddf-48e77e70e316</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='LLD'])[1]/following::span[4]</value>
      <webElementGuid>416d905e-2548-421c-a27e-f246924dc133</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Report Non Bank'])[1]/preceding::span[1]</value>
      <webElementGuid>18943dac-70b1-49bc-93be-2240dd0794f3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Internal Validation'])[1]/preceding::span[3]</value>
      <webElementGuid>fce0377f-be76-45d1-be5d-a418f59e9643</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Report Bank']/parent::*</value>
      <webElementGuid>5a8bd545-cc77-4f50-8042-aefb9e507a2c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li[10]/ul/li[2]/div/span/div/span</value>
      <webElementGuid>1adbad74-8306-40c3-946d-004b9270eebf</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[@title = 'Report Bank' and (text() = 'Report Bank' or . = 'Report Bank')]</value>
      <webElementGuid>87c3d61e-7bb5-4785-a452-646e70da24dc</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
