<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_LLD2 - Laporan Posisi</name>
   <tag></tag>
   <elementGuidId>62c05172-f9eb-4c31-9b27-fe5352249542</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>li.ant-menu-item.ant-menu-item-active.ant-menu-item-only-child > span.ant-menu-title-content > a</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//ul[@id='rc-menu-uuid-22930-1-10_2-popup']/li[2]/span/a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;LLD2 - Laporan Posisi&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>3d447fbc-9c30-48e0-9f0a-f9aa63f30670</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>/form/F_LLD2</value>
      <webElementGuid>f452400a-1dc6-41ff-ac3d-0f40771beac4</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>LLD2 - Laporan Posisi</value>
      <webElementGuid>eb2bd97b-0c21-449b-a701-c3a1e5ac2e6e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;rc-menu-uuid-22930-1-10_2-popup&quot;)/li[@class=&quot;ant-menu-item ant-menu-item-active ant-menu-item-only-child&quot;]/span[@class=&quot;ant-menu-title-content&quot;]/a[1]</value>
      <webElementGuid>a628134f-301d-43f1-bff6-db92973dd6bb</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//ul[@id='rc-menu-uuid-22930-1-10_2-popup']/li[2]/span/a</value>
      <webElementGuid>1de65874-3ba1-449e-bb26-8f613ed7f3f5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='LLD1 - Laporan Transaksi'])[1]/following::a[1]</value>
      <webElementGuid>c477cd18-8490-4e04-bf86-e37d65d8874a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Report Bank'])[1]/following::a[2]</value>
      <webElementGuid>b1bc08e5-0c16-44f0-a1b9-3fa2d409ace0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='RKD1 - Laporan Transaksi Reksus'])[1]/preceding::a[1]</value>
      <webElementGuid>e091a067-6ae4-49ee-b48a-b6f74e12b57e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, '/form/F_LLD2')]</value>
      <webElementGuid>88f920dc-09f7-4899-96ab-e1c640442e4b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li[2]/span/a</value>
      <webElementGuid>d282a1db-e449-4648-906c-a4492ef19825</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '/form/F_LLD2' and (text() = 'LLD2 - Laporan Posisi' or . = 'LLD2 - Laporan Posisi')]</value>
      <webElementGuid>d083c007-8ec3-471d-addf-1548e8c161d0</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
