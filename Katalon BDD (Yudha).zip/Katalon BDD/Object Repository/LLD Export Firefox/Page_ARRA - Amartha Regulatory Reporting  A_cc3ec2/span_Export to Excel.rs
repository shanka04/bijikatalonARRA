<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_Export to Excel</name>
   <tag></tag>
   <elementGuidId>8ab70161-8c6a-4efe-ab8d-d1f13947d987</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>#27bd49c5-7d23-4c64-838e-93ac16fe7af0_0 > li.k-item.k-menu-item.k-first > span.k-link.k-menu-link > span.k-menu-link-text</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//ul[@id='27bd49c5-7d23-4c64-838e-93ac16fe7af0_0']/li/span/span[2]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:text=&quot;Export to Excel&quot;i</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>dd0a44b4-511e-4af0-b5e2-f99c1826030c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>k-menu-link-text</value>
      <webElementGuid>7d902cf4-e101-403f-973a-25b3b35d3d7d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Export to Excel</value>
      <webElementGuid>05593aca-31a4-444b-b12c-625da1074c55</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;27bd49c5-7d23-4c64-838e-93ac16fe7af0_0&quot;)/li[@class=&quot;k-item k-menu-item k-first&quot;]/span[@class=&quot;k-link k-menu-link&quot;]/span[@class=&quot;k-menu-link-text&quot;]</value>
      <webElementGuid>110193e2-c39e-4d91-994a-aa82ef4f9a9f</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//ul[@id='27bd49c5-7d23-4c64-838e-93ac16fe7af0_0']/li/span/span[2]</value>
      <webElementGuid>6425baae-8324-4c99-a89d-211cfa326bab</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Amartha Regulatory Reporting &amp; Analytics (ARRA)'])[1]/following::span[3]</value>
      <webElementGuid>6c2d1d0d-54c8-4f1b-923d-591215c177ea</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='+'])[3]/following::span[9]</value>
      <webElementGuid>3c382a05-4cc7-498f-89e5-0de4d685e5cf</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Export to CSV'])[1]/preceding::span[2]</value>
      <webElementGuid>21c65d3e-1c8b-43b1-8729-54d2726731e7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Export to Delimited TF'])[1]/preceding::span[5]</value>
      <webElementGuid>4470041a-9308-498e-8dc3-91b3f99a6405</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Export to Excel']/parent::*</value>
      <webElementGuid>f5031185-2262-4831-95f0-70ef705a5f10</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//body/div[2]/div/ul/li/span/span[2]</value>
      <webElementGuid>3b8f8d91-dd3b-445c-a520-2239d8c445ec</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = 'Export to Excel' or . = 'Export to Excel')]</value>
      <webElementGuid>27d30a94-af6c-47c7-9492-341161edf29b</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
