<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_HR Module</name>
   <tag></tag>
   <elementGuidId>3d9abc36-5cbd-4aba-a50e-3842634c5873</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='root']/div/div[2]/div[2]/header[2]/div/div/div/div/div/div/div/div/div/ul/li[2]/a/div/span/div</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>a >> internal:has-text=&quot;HRHR Module&quot;i</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>1e2d2563-c2b8-4b9e-9728-40354ba19e27</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>HR Module</value>
      <webElementGuid>4c42d3f1-c972-4003-a03c-417c56ffbf82</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;root&quot;)/div[@class=&quot;css-1bwh1q9 ant-design-pro ant-pro-layout screen-xl ant-pro-layout-fix-siderbar ant-pro-layout-mix&quot;]/div[@class=&quot;ant-layout ant-layout-has-sider css-46oa5i&quot;]/div[@class=&quot;ant-pro-layout-container css-1bwh1q9&quot;]/header[@class=&quot;ant-layout-header css-1bwh1q9 ant-pro-layout-header ant-pro-layout-header-fixed-header ant-pro-layout-header-mix ant-pro-layout-header-fixed-header-action ant-pro-layout-header-header css-2g6vcy&quot;]/div[@class=&quot;ant-pro-top-nav-header css-1bwh1q9 ant-pro-top-nav-header-light&quot;]/div[@class=&quot;ant-pro-top-nav-header-main css-1bwh1q9&quot;]/div[@class=&quot;ant-pro-top-nav-header-main-left css-1bwh1q9&quot;]/div[1]/div[@class=&quot;ant-popover ant-pro-layout-apps-popover css-1bwh1q9 css-2g6vcy css-2g6vcy ant-popover-placement-bottomLeft&quot;]/div[@class=&quot;ant-popover-content&quot;]/div[@class=&quot;ant-popover-inner&quot;]/div[@class=&quot;ant-popover-inner-content&quot;]/div[@class=&quot;ant-pro-layout-apps-default-content css-1bwh1q9&quot;]/ul[@class=&quot;ant-pro-layout-apps-default-content-list css-1bwh1q9&quot;]/li[@class=&quot;ant-pro-layout-apps-default-content-list-item css-1bwh1q9&quot;]/a[1]/div[1]/span[1]/div[1]</value>
      <webElementGuid>05b337f2-6132-480f-b6d4-97f6363854cb</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='root']/div/div[2]/div[2]/header[2]/div/div/div/div/div/div/div/div/div/ul/li[2]/a/div/span/div</value>
      <webElementGuid>466d8326-ac2a-4fe7-9337-d4161a05b940</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='HR'])[1]/following::div[1]</value>
      <webElementGuid>966226a0-7574-4430-b4ae-e68fd1bfec20</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='GLOBAL Module'])[1]/following::div[4]</value>
      <webElementGuid>59e2adc2-8ace-4432-9bda-e8831a2e6d07</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='GLOBAL'])[3]/preceding::div[1]</value>
      <webElementGuid>d1269432-dd72-4a82-bf8c-732cc3b421f0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Master Data'])[1]/preceding::div[3]</value>
      <webElementGuid>af2547a7-6253-4b8e-8e25-c53ea006f637</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='HR Module']/parent::*</value>
      <webElementGuid>382d2ec3-6174-44e0-a759-7cafc9f796dd</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li[2]/a/div/span/div</value>
      <webElementGuid>2f26a289-66b7-439b-9f94-3522367b213c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = 'HR Module' or . = 'HR Module')]</value>
      <webElementGuid>a9cac922-88a9-48ec-9060-4d24ed77da0a</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
