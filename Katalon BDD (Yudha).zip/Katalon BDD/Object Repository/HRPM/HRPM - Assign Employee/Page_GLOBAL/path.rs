<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>path</name>
   <tag></tag>
   <elementGuidId>9419dd47-1454-46e1-b07a-22881f3f802b</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>span.ant-pro-layout-apps-icon.css-1bwh1q9 > svg > path</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>path >> nth=1</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>path</value>
      <webElementGuid>be8389d6-069f-4219-bc71-7e594925c7dc</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>d</name>
      <type>Main</type>
      <value>M0 0h3v3H0V0zm4.5 0h3v3h-3V0zM9 0h3v3H9V0zM0 4.5h3v3H0v-3zm4.503 0h3v3h-3v-3zM9 4.5h3v3H9v-3zM0 9h3v3H0V9zm4.503 0h3v3h-3V9zM9 9h3v3H9V9z</value>
      <webElementGuid>eae9020e-3acc-4c3e-86b5-7d6e3edcd86b</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;root&quot;)/div[@class=&quot;css-1bwh1q9 ant-design-pro ant-pro-layout screen-xl ant-pro-layout-fix-siderbar ant-pro-layout-mix&quot;]/div[@class=&quot;ant-layout ant-layout-has-sider css-46oa5i&quot;]/div[@class=&quot;ant-pro-layout-container css-1bwh1q9&quot;]/header[@class=&quot;ant-layout-header css-1bwh1q9 ant-pro-layout-header ant-pro-layout-header-fixed-header ant-pro-layout-header-mix ant-pro-layout-header-fixed-header-action ant-pro-layout-header-header css-2g6vcy&quot;]/div[@class=&quot;ant-pro-top-nav-header css-1bwh1q9 ant-pro-top-nav-header-light&quot;]/div[@class=&quot;ant-pro-top-nav-header-main css-1bwh1q9&quot;]/div[@class=&quot;ant-pro-top-nav-header-main-left css-1bwh1q9&quot;]/span[@class=&quot;ant-pro-layout-apps-icon css-1bwh1q9&quot;]/svg[1]/path[1]</value>
      <webElementGuid>ab7378b4-599e-4fba-bb91-b85cfad8cdf6</webElementGuid>
   </webElementProperties>
</WebElementEntity>
