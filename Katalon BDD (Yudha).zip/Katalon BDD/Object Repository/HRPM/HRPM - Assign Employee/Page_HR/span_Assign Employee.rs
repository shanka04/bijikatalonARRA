<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_Assign Employee</name>
   <tag></tag>
   <elementGuidId>f1700239-2613-4419-b53a-d4f138721c03</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>li.ant-menu-item.ant-menu-item-active.ant-menu-item-only-child.ant-pro-base-menu-inline-menu-item > span.ant-menu-title-content > div > div.ant-pro-base-menu-inline-item-title.css-1bwh1q9 > span.ant-pro-base-menu-inline-item-text.css-1bwh1q9</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='root']/div/div[2]/aside/div/div/ul/li[2]/ul/li[2]/span/div/div/span[2]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:text=&quot;Assign Employee&quot;i</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>9c3c391a-adf0-4ec2-b55b-dd678d82f968</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>ant-pro-base-menu-inline-item-text css-1bwh1q9</value>
      <webElementGuid>940c6213-9887-4449-b397-5c226820c92b</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Assign Employee</value>
      <webElementGuid>aebfd1f4-99c6-46c6-8b79-57fe83479eae</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;root&quot;)/div[@class=&quot;css-1bwh1q9 ant-design-pro ant-pro-layout screen-xl ant-pro-layout-fix-siderbar ant-pro-layout-mix&quot;]/div[@class=&quot;ant-layout ant-layout-has-sider css-46oa5i&quot;]/aside[@class=&quot;ant-layout-sider ant-layout-sider-dark ant-pro-sider css-1bwh1q9 ant-pro-sider-fixed ant-pro-sider-fixed-mix ant-pro-sider-layout-mix ant-pro-sider-light ant-pro-sider-mix css-1bwh1q9&quot;]/div[@class=&quot;ant-layout-sider-children&quot;]/div[1]/ul[@class=&quot;ant-menu ant-menu-root ant-menu-inline ant-menu-light ant-pro-sider-menu css-1bwh1q9 css-1bwh1q9 ant-pro-base-menu-inline css-1wf9axr&quot;]/li[@class=&quot;ant-menu-item-group ant-pro-base-menu-inline-group&quot;]/ul[@class=&quot;ant-menu-item-group-list&quot;]/li[@class=&quot;ant-menu-item ant-menu-item-active ant-menu-item-only-child ant-pro-base-menu-inline-menu-item&quot;]/span[@class=&quot;ant-menu-title-content&quot;]/div[1]/div[@class=&quot;ant-pro-base-menu-inline-item-title css-1bwh1q9&quot;]/span[@class=&quot;ant-pro-base-menu-inline-item-text css-1bwh1q9&quot;]</value>
      <webElementGuid>2ed28170-acb5-4e91-830b-de55f98476c5</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='root']/div/div[2]/aside/div/div/ul/li[2]/ul/li[2]/span/div/div/span[2]</value>
      <webElementGuid>c858a40f-a12e-4f45-a7c7-3eea94050094</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Competencies Dictionary'])[1]/following::span[4]</value>
      <webElementGuid>f88903dd-8cf8-4b35-8532-1816092d655a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Competencies'])[1]/following::span[8]</value>
      <webElementGuid>4c1babb0-14e4-4561-8641-126dea8607a8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Services'])[1]/preceding::span[1]</value>
      <webElementGuid>5f87113e-1d3d-40f9-8b77-8fbe6da50c4b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Email Reminder'])[1]/preceding::span[4]</value>
      <webElementGuid>8c3ba0d7-f34c-4cd3-bd1e-aab28da99a3a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Assign Employee']/parent::*</value>
      <webElementGuid>d557ff20-ac0e-48ca-b110-45c7ef3fbb7f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li[2]/span/div/div/span[2]</value>
      <webElementGuid>bf8f386e-bf1e-437c-a366-fafe103ce924</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = 'Assign Employee' or . = 'Assign Employee')]</value>
      <webElementGuid>8843dabb-b0e0-43a2-a1cc-faee4fbdd714</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
