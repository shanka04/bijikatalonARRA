<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>edit</name>
   <tag></tag>
   <elementGuidId>0f791128-788a-4dec-bc3a-b7675c008590</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//td[@class='ant-table-cell ant-table-cell-fix-left ant-table-cell-fix-left-last ant-table-cell-row-hover']//div[2]//button[1]//img[1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
