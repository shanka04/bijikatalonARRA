<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>button_Submit Note_ant-btn css-kd7ytk ant-btn-text</name>
   <tag></tag>
   <elementGuidId>6a793456-5816-48dd-9bb1-b6fb57eaf9a0</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//td[@class='ant-table-cell ant-table-cell-row-hover']//img</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value>//*[@type = 'button']</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>td.ant-table-cell > button.ant-btn.css-kd7ytk.ant-btn-text</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=row[name=&quot;EDIT HR Assign Employee adminhr 2024-12-11T21:52:38.055706 ok&quot;i] >> internal:role=button</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>button</value>
      <webElementGuid>0ffe2d93-b15d-4da0-a744-7f258f7a13ca</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>type</name>
      <type>Main</type>
      <value>button</value>
      <webElementGuid>2c0c1dd2-3e7a-450b-8310-bdeb35365ac0</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>ant-btn css-kd7ytk ant-btn-text</value>
      <webElementGuid>36784b14-c706-485e-8512-73cda859ca73</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;root&quot;)/div[@class=&quot;css-kd7ytk ant-design-pro ant-pro-layout screen-xl ant-pro-layout-fix-siderbar ant-pro-layout-mix&quot;]/div[@class=&quot;ant-layout ant-layout-has-sider css-kd7ytk&quot;]/div[@class=&quot;ant-pro-layout-container css-kd7ytk&quot;]/main[@class=&quot;ant-layout-content ant-pro-layout-content css-kd7ytk ant-pro-layout-has-header ant-pro-layout-content-has-page-container css-kd7ytk&quot;]/div[@class=&quot;ant-pro-page-container css-kd7ytk&quot;]/div[@class=&quot;ant-pro-grid-content css-kd7ytk&quot;]/div[@class=&quot;ant-pro-grid-content-children css-kd7ytk&quot;]/div[@class=&quot;css-kd7ytk ant-pro-page-container-children-container&quot;]/div[@class=&quot;ant-pro-card css-kd7ytk&quot;]/div[@class=&quot;ant-pro-card-body css-kd7ytk&quot;]/div[1]/div[@class=&quot;ant-pro-table css-kd7ytk&quot;]/div[@class=&quot;ant-table-wrapper css-kd7ytk&quot;]/div[@class=&quot;ant-spin-nested-loading css-kd7ytk&quot;]/div[@class=&quot;ant-spin-container&quot;]/div[@class=&quot;ant-table ant-table-small css-kd7ytk ant-table-ping-right ant-table-scroll-horizontal&quot;]/div[@class=&quot;ant-table-container&quot;]/div[@class=&quot;ant-table-content&quot;]/table[1]/tbody[@class=&quot;ant-table-tbody&quot;]/tr[@class=&quot;ant-table-row ant-table-row-level-0&quot;]/td[@class=&quot;ant-table-cell&quot;]/button[@class=&quot;ant-btn css-kd7ytk ant-btn-text&quot;]</value>
      <webElementGuid>ca4fb9c7-5b0f-4dc2-9e15-a4bf8cdb56ef</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:attributes</name>
      <type>Main</type>
      <value>(//button[@type='button'])[2]</value>
      <webElementGuid>e0c199dd-d24f-4178-884e-9be0aa736a67</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='root']/div/div[2]/div[2]/main/div/div[2]/div/div/div/div/div/div[2]/div[2]/div/div/div/div/div/table/tbody/tr[2]/td/button</value>
      <webElementGuid>aa92436f-d44d-44ed-a1ab-b742ad73cfee</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Submit Note'])[1]/following::button[1]</value>
      <webElementGuid>82fe1274-be19-4f80-8f3b-8b06c508b841</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Request Date'])[1]/following::button[1]</value>
      <webElementGuid>1b9495e1-37fb-43ec-b5db-8cd7302fe6ee</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='EDIT'])[1]/preceding::button[1]</value>
      <webElementGuid>bf728c5f-2763-4133-9619-5a52df1343de</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='HR'])[1]/preceding::button[1]</value>
      <webElementGuid>3da7291b-8370-4843-ab89-db3d1ad72054</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//td/button</value>
      <webElementGuid>e1a18bf3-0c40-4ef8-afd6-152a1f6fa736</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//button[@type = 'button']</value>
      <webElementGuid>2b5250c6-49d5-415d-af07-fb05dc7f7f51</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
