<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_Task List</name>
   <tag></tag>
   <elementGuidId>50b02cbc-bb18-4181-bcdc-3602b7b98a07</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//span[(text() = 'Task List' or . = 'Task List')]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value>//*[(text() = 'Task List' or . = 'Task List')]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>span.ant-pro-base-menu-inline-item-text.css-k9cz9b</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=complementary >> internal:text=&quot;Task List&quot;i</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>67c438b8-45a1-4617-b734-462faa517394</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>ant-pro-base-menu-inline-item-text css-k9cz9b</value>
      <webElementGuid>ff0cae89-c531-4a5a-93f7-de463ef30328</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Task List</value>
      <webElementGuid>2986398f-74dd-4434-b7b2-a6abe16b7866</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;root&quot;)/div[@class=&quot;css-kd7ytk ant-design-pro ant-pro-layout screen-xl ant-pro-layout-fix-siderbar ant-pro-layout-mix&quot;]/div[@class=&quot;ant-layout ant-layout-has-sider css-kd7ytk&quot;]/aside[@class=&quot;ant-layout-sider ant-layout-sider-dark ant-pro-sider css-kd7ytk ant-pro-sider-fixed ant-pro-sider-fixed-mix ant-pro-sider-layout-mix ant-pro-sider-light ant-pro-sider-mix css-kd7ytk&quot;]/div[@class=&quot;ant-layout-sider-children&quot;]/div[1]/ul[@class=&quot;ant-menu ant-menu-root ant-menu-inline ant-menu-light ant-pro-sider-menu css-kd7ytk css-k9cz9b ant-pro-base-menu-inline css-k9cz9b&quot;]/li[@class=&quot;ant-menu-item ant-menu-item-only-child ant-pro-base-menu-inline-menu-item&quot;]/span[@class=&quot;ant-menu-title-content&quot;]/div[1]/div[@class=&quot;ant-pro-base-menu-inline-item-title css-k9cz9b&quot;]/span[@class=&quot;ant-pro-base-menu-inline-item-text css-k9cz9b&quot;]</value>
      <webElementGuid>048c7d89-05e1-4739-9866-a80043cc830c</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='root']/div/div[2]/aside/div/div/ul/li/span/div/div/span[2]</value>
      <webElementGuid>73ac062b-d874-4591-99a6-773ed09e49d0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Submitted List'])[1]/preceding::span[3]</value>
      <webElementGuid>890d21b1-55ef-4fcf-9e4e-a80daa7c54db</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Task List']/parent::*</value>
      <webElementGuid>02c4223a-3ac4-4c2e-af69-6b0470ff9dcd</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//span[2]</value>
      <webElementGuid>76cf6edc-267c-4fa9-b268-8a4137c4f3fa</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = 'Task List' or . = 'Task List')]</value>
      <webElementGuid>056f64a1-390c-40ec-bfb6-16ba7d64963c</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
