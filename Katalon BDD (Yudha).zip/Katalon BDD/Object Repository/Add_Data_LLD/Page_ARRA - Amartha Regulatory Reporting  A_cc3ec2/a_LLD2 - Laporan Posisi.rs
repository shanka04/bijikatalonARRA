<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_LLD2 - Laporan Posisi</name>
   <tag></tag>
   <elementGuidId>8a9132c3-cf30-488c-97f5-fca6273c39c1</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//ul[@id='rc-menu-uuid-30905-1-10_2-popup']/li[2]/span/a</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>li.ant-menu-item.ant-menu-item-active.ant-menu-item-only-child > span.ant-menu-title-content > a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;LLD2 - Laporan Posisi&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>d183a016-bfbf-4515-8225-d0932dc056b5</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>/form/F_LLD2</value>
      <webElementGuid>16093fbe-9760-4d2d-9a4c-ae00e7dd4005</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>LLD2 - Laporan Posisi</value>
      <webElementGuid>0a9af3b5-dd65-4ae5-a3bf-ad76d83f4119</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;rc-menu-uuid-30905-1-10_2-popup&quot;)/li[@class=&quot;ant-menu-item ant-menu-item-active ant-menu-item-only-child&quot;]/span[@class=&quot;ant-menu-title-content&quot;]/a[1]</value>
      <webElementGuid>4c70ac38-be9c-4726-a851-32bfbe61d7a6</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//ul[@id='rc-menu-uuid-30905-1-10_2-popup']/li[2]/span/a</value>
      <webElementGuid>552935eb-7ef6-4ce5-8b54-796a430f8cc2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='LLD1 - Laporan Transaksi'])[1]/following::a[1]</value>
      <webElementGuid>1f04f328-90a3-4af1-8969-96c46f5ea095</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Report Bank'])[1]/following::a[2]</value>
      <webElementGuid>8ffdebad-1903-494f-ac95-7114bec3b153</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='RKD1 - Laporan Transaksi Reksus'])[1]/preceding::a[1]</value>
      <webElementGuid>ffbb1208-eb43-4f9d-9da7-d37732dcc5f8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, '/form/F_LLD2')]</value>
      <webElementGuid>c12a4568-8310-46c6-8d7c-e4cfa15f41ca</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li[2]/span/a</value>
      <webElementGuid>3feb5999-d228-4539-80b4-2e537fd86f1c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '/form/F_LLD2' and (text() = 'LLD2 - Laporan Posisi' or . = 'LLD2 - Laporan Posisi')]</value>
      <webElementGuid>a9b947d8-b4e3-4b62-8df8-c053f2471e5d</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
