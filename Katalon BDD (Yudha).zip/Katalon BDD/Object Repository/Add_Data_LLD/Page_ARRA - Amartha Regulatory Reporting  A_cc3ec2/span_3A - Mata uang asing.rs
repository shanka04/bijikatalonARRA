<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_3A - Mata uang asing</name>
   <tag></tag>
   <elementGuidId>5f7bd63c-ce06-43ba-93e7-7524cfb927db</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//li[@id='option-ff961e53-6866-4669-9ac6-afa67342fcd2-0']/span</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>span[title=&quot;Param Code: LLD011&quot;]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:text=&quot;3A - Mata uang asing&quot;i</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>0f0eff1c-8b91-4898-af2d-e82d34e0ea29</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>title</name>
      <type>Main</type>
      <value>Param Code: LLD011</value>
      <webElementGuid>c950f09d-3e75-4673-b68e-cd8966e2f575</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>3A - Mata uang asing </value>
      <webElementGuid>6a6d8bb8-73e2-4d0a-a040-122563ac7014</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;option-ff961e53-6866-4669-9ac6-afa67342fcd2-0&quot;)/span[1]</value>
      <webElementGuid>bfaad989-cdb8-41d1-b0f5-f7bce94513bb</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//li[@id='option-ff961e53-6866-4669-9ac6-afa67342fcd2-0']/span</value>
      <webElementGuid>4d2c833d-6c82-4a4e-ab9f-bf635e548c52</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Save'])[1]/following::span[1]</value>
      <webElementGuid>8bcd6e68-db3f-412e-9de7-e04234a08c57</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Cancel'])[1]/following::span[2]</value>
      <webElementGuid>1d5cd4c8-e735-4eab-bb62-17cfb07d3e53</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='3A - Mata uang asing']/parent::*</value>
      <webElementGuid>936c708e-d0f4-4227-a56a-a71709f400a4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[3]/div/div/div/ul/li/span</value>
      <webElementGuid>38ad1e28-7543-423d-a440-52447726e4ed</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[@title = 'Param Code: LLD011' and (text() = '3A - Mata uang asing ' or . = '3A - Mata uang asing ')]</value>
      <webElementGuid>0383cb4b-cba2-4737-ac5c-d0b92ef4a082</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
