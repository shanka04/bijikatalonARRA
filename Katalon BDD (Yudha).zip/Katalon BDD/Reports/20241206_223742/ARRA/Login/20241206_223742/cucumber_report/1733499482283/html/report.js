$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("C:/Users/batm/Katalon Studio/Katalon BDD/Include/features/Login.feature");
formatter.feature({
  "name": "login",
  "description": "  I want to use this template for my feature file",
  "keyword": "Feature"
});
formatter.scenario({
  "name": "login",
  "description": "",
  "keyword": "Scenario"
});
formatter.step({
  "name": "User Access URL",
  "keyword": "Given "
});
formatter.match({
  "location": "login.AccessURL()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "User Input Valid Credentials",
  "keyword": "When "
});
formatter.match({
  "location": "login.InputCredentials()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "User Click Button Login",
  "keyword": "And "
});
formatter.match({
  "location": "login.Kliklogin()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "Showing ARRA dashboard",
  "keyword": "Then "
});
formatter.match({
  "location": "login.ARRAdashboard()"
});
formatter.result({
  "status": "passed"
});
});