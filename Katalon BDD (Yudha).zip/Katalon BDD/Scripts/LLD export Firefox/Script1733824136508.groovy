import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testng.keyword.TestNGBuiltinKeywords as TestNGKW
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import internal.GlobalVariable as GlobalVariable
import org.openqa.selenium.Keys as Keys
import java.awt.Desktop
import java.io.File

import java.nio.file.Files
import java.nio.file.Paths
import java.util.Date

WebUI.openBrowser('')

WebUI.navigateToUrl('http://192.168.1.42:8081/login')

WebUI.setText(findTestObject('Object Repository/LLD Export Firefox/Page_Login  ARRA - Amartha Regulatory Repor_fe642d/input_Username_username'), 
    'sa')

WebUI.setEncryptedText(findTestObject('Object Repository/LLD Export Firefox/Page_Login  ARRA - Amartha Regulatory Repor_fe642d/input_Password_password'), 
    'iFGeFYmXIrUhQZHvW7P22w==')

WebUI.sendKeys(findTestObject('Object Repository/LLD Export Firefox/Page_Login  ARRA - Amartha Regulatory Repor_fe642d/input_Password_password'), 
    Keys.chord(Keys.ENTER))

WebUI.click(findTestObject('Object Repository/LLD Export Firefox/Page_ARRA - Amartha Regulatory Reporting  A_cc3ec2/div_LLD'))

WebUI.click(findTestObject('Object Repository/LLD Export Firefox/Page_ARRA - Amartha Regulatory Reporting  A_cc3ec2/span_Report Bank'))

WebUI.click(findTestObject('Object Repository/LLD Export Firefox/Page_ARRA - Amartha Regulatory Reporting  A_cc3ec2/a_LLD2 - Laporan Posisi'))

WebUI.click(findTestObject('Object Repository/LLD Export Firefox/Page_ARRA - Amartha Regulatory Reporting  A_cc3ec2/span_ACTIONS'))

WebUI.click(findTestObject('Object Repository/LLD Export Firefox/Page_ARRA - Amartha Regulatory Reporting  A_cc3ec2/span_Export to Excel'))

WebUI.newTab('')

WebUI.navigateToUrl('http://192.168.1.42:8081/download/F_LLD2/167101?fnm=Laporan%20Posisi%20(%202023-12-31%20)%20.xlsx&ftp=EXCEL&prfx=Form')

WebUI.click(findTestObject('Object Repository/LLD Export Firefox/Page_ARRA - Amartha Regulatory Reporting  A_cc3ec2/a_Download Here'))


WebUI.delay(5)


//File downloadedFile = new File("C:\\Users\\batm\\Downloads\\Laporan Posisi ( 2023-12-31 )  (4).xlsx")
//WebUI.delay(3)
//
//Desktop.getDesktop().open(downloadedFile)
//WebUI.delay(10)


// Tentukan folder Downloads
File downloadsFolder = new File("C:\\Users\\batm\\Downloads")

// Mendapatkan daftar semua file dengan ekstensi .xlsx dalam folder Downloads
File[] files = downloadsFolder.listFiles({ dir, name -> name.endsWith(".xlsx") } as FilenameFilter)

// Menemukan file terbaru berdasarkan tanggal modifikasi
File latestFile = null
long latestModified = 0

// Iterasi untuk menemukan file dengan tanggal modifikasi terbaru
files.each { file ->
	if (file.lastModified() > latestModified) {
		latestModified = file.lastModified()
		latestFile = file
	}
}

// Jika file terbaru ditemukan, buka file tersebut
if (latestFile != null) {
	WebUI.delay(3)
	Desktop.getDesktop().open(latestFile)
	WebUI.delay(10)
} else {
	println("Tidak ada file Excel ditemukan di folder Downloads.")
}


WebUI.delay(4)

try {
	Runtime.getRuntime().exec("taskkill /f /im excel.exe")
	println("Excel telah ditutup.")
} 
catch (IOException e) {
	println("Gagal menutup Excel: " + e.getMessage())
}
